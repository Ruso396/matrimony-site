import express from "express";
import {
  sendInterestRequest,
  handleRequestResponse,
  getRequestStatus,
  getAllInterestRequests, // <--- correct placement
} from "../controllers/requestController";

const router = express.Router();

// POST /api/request/send
router.post("/send", sendInterestRequest);
router.get("/respond", handleRequestResponse);
router.get("/status", getRequestStatus); 
router.get("/all", getAllInterestRequests); // ✅ new route

export default router;

declare module 'sharp' {
  const sharp: any;
  export default sharp;
}

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MessageCircle, Search, Filter, Clock, CheckCircle, XCircle, AlertCircle, Eye } from 'lucide-react';

interface UserInfo {
  id: number;
  fullName: string;
  age: number;
  profession: string;
  city: string;
  profileImage?: string;
}

interface InterestRequest {
  id: number;
  sender: UserInfo;
  receiver: UserInfo;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

const InterestRequests = () => {
  const [requests, setRequests] = useState<InterestRequest[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [loading, setLoading] = useState(true);

  // ✅ Fetch API data
  useEffect(() => {
    const fetchRequests = async () => {
      try {
        setLoading(true);
        const res = await axios.get('http://localhost:5000/api/request/all');
        setRequests(res.data.data);
      } catch (err) {
        console.error("❌ Error fetching interest requests:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchRequests();
  }, []);

  // ✅ Filter Logic
  const filteredRequests = requests.filter((req) => {
    const matchesSearch =
      req.sender.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.receiver.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.sender.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.receiver.city.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterStatus === 'all' || req.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  // ✅ Status Style Config
  const getStatusConfig = (status: 'pending' | 'accepted' | 'rejected') => {
    switch (status) {
      case 'pending':
        return { color: 'bg-yellow-100 text-yellow-800 border-yellow-300', icon: Clock, label: 'Pending' };
      case 'accepted':
        return { color: 'bg-green-100 text-green-800 border-green-300', icon: CheckCircle, label: 'Accepted' };
      case 'rejected':
        return { color: 'bg-red-100 text-red-800 border-red-300', icon: XCircle, label: 'Rejected' };
      default:
        return { color: 'bg-gray-100 text-gray-800 border-gray-300', icon: AlertCircle, label: status };
    }
  };

  // ✅ Stats
  const stats = {
    total: requests.length,
    pending: requests.filter(r => r.status === 'pending').length,
    accepted: requests.filter(r => r.status === 'accepted').length,
    rejected: requests.filter(r => r.status === 'rejected').length
  };

  if (loading) {
    return (
      <div className="p-6 text-center text-gray-600">
        <MessageCircle className="w-12 h-12 mx-auto text-blue-400 animate-pulse" />
        <p className="mt-2">Loading Interest Requests...</p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <MessageCircle className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-800">Interest Requests Management</h1>
          </div>
          <p className="text-gray-600">Monitor and track all interest requests between users</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-gray-600 text-sm mb-1">Total Requests</div>
            <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-gray-600 text-sm mb-1">Pending</div>
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-gray-600 text-sm mb-1">Accepted</div>
            <div className="text-2xl font-bold text-green-600">{stats.accepted}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <div className="text-gray-600 text-sm mb-1">Rejected</div>
            <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="bg-white p-4 rounded-lg shadow mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search by name or city..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-600" />
              <select
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All</option>
                <option value="pending">Pending</option>
                <option value="accepted">Accepted</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </div>

        {/* List */}
        <div className="space-y-4">
          {filteredRequests.map((req) => {
            const statusConfig = getStatusConfig(req.status);
            const StatusIcon = statusConfig.icon;
            return (
              <div key={req.id} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-semibold text-gray-700">Request #{req.id}</h2>
                  <span className={`flex items-center gap-2 px-3 py-1 rounded-lg border-2 font-semibold text-sm ${statusConfig.color}`}>
                    <StatusIcon className="w-4 h-4" /> {statusConfig.label}
                  </span>
                </div>

                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-xs text-blue-600 font-semibold mb-2">FROM</p>
                    <div className="flex items-start gap-3">
                      <img src={req.sender.profileImage || 'https://via.placeholder.com/50'} alt="sender" className="w-12 h-12 rounded-full object-cover" />
                      <div>
                        <p className="font-bold text-gray-800">{req.sender.fullName}</p>
                        <p className="text-sm text-gray-600">{req.sender.age} yrs</p>
                        <p className="text-sm text-gray-600">{req.sender.profession}</p>
                        <p className="text-sm text-gray-600">{req.sender.city}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center text-3xl text-blue-600">→</div>

                  <div className="bg-purple-50 p-4 rounded-lg">
                    <p className="text-xs text-purple-600 font-semibold mb-2">TO</p>
                    <div className="flex items-start gap-3">
                      <img src={req.receiver.profileImage || 'https://via.placeholder.com/50'} alt="receiver" className="w-12 h-12 rounded-full object-cover" />
                      <div>
                        <p className="font-bold text-gray-800">{req.receiver.fullName}</p>
                        <p className="text-sm text-gray-600">{req.receiver.age} yrs</p>
                        <p className="text-sm text-gray-600">{req.receiver.profession}</p>
                        <p className="text-sm text-gray-600">{req.receiver.city}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-sm text-gray-600 flex gap-4">
                  <span>Created: {new Date(req.createdAt).toLocaleString()}</span>
                  {req.status !== 'pending' && (
                    <span>Updated: {new Date(req.updatedAt).toLocaleString()}</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {filteredRequests.length === 0 && (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No Requests Found</h3>
            <p className="text-gray-500">Try adjusting your search or filter</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default InterestRequests;
